//
//  UserAuth.swift
//  YeDi
//
//  Created by 이승준 on 2023/09/25.
//

import SwiftUI
import Combine

class UserAuth: ObservableObject {
    @Published var isLogged = false
}

